% Add folders to path.
addpath(pwd);

cd manopt;
addpath(genpath(pwd));
cd ..;

cd utils;
addpath(genpath(pwd));
cd ..;

cd DHMNet;
addpath(genpath(pwd));
cd ..;



