# DHMNet

Note that the copyright of the manopt toolbox is reserved by https://www.manopt.org/  

## Usage
Step1: Launch DHMNet_afew.m for a simple example.